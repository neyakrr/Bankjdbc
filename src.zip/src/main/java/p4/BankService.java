package p4;

public class BankService {
	public void transferMoney()
{
	System.out.println("Money transferred successfully for user: ");
}

}
