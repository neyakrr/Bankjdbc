package p6;

import org.springframework.stereotype.Controller;

@Controller
public class MainController {
	
	@RequestMapping("/home")
	public String Transfer()
	{
		return Transfer;
	}

}
