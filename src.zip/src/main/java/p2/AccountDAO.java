package p2;

import java.util.List;

public interface AccountDAO {
	void update(Account e);
	List<Integer> getAcc();

}
